#include <Arduino.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <WiFi.h>
#include <EEPROM.h>
#include <esp_pm.h>
#include <esp_wifi_types.h>
#include <dataStructs.h>
#include <globals.h>
#include <utils.h>
#include <espnow-pairing.h>
#include <otaManager.h>
#include <espnow.h>

MessageType messageType;

void setup() {
    delay(5000);
    Serial.begin(115200);
    pinMode(STATUS_LED_PIN, OUTPUT);
    pinMode(PAIRING_BUTTON_PIN, INPUT_PULLUP);
      //Setup LED
    ledcSetup(LEDC_CHANNEL_0, LEDC_BASE_FREQ, LEDC_TIMER_13_BIT);
    ledcAttachPin(PAIRING_LED_PIN, LEDC_CHANNEL_0);
    log(LOG_ERROR, "Client setup starting...");
    WiFi.mode(WIFI_STA);
    esp_wifi_set_ps(WIFI_PS_NONE);
    WiFi.begin();
    log(LOG_ERROR,"Client Board MAC Address:  ");
    esp_wifi_get_mac(WIFI_IF_STA, clientMacAddress);
    printMAC(clientMacAddress, LOG_INFO);
    WiFi.disconnect();
    start = millis();
    unsigned long serialWaitStart = millis();
    log(LOG_ERROR,"Enter 'ota' within 10 seconds to enter OTA mode...");

    while (millis() - serialWaitStart < 10000) {
        checkSerialCommands();
        delay(10);
        if (serialOtaTrigger) break;
    }

    if (checkOtaTrigger() || serialOtaTrigger) {
        //updatePairingLED();
        startOTA();
        return;
    }
        printMAC(clientMacAddress, LOG_INFO);

    if (!loadServerFromNVS(serverAddress, &currentChannel)) {
        log(LOG_ERROR, "[Client] No paired server in NVS, starting pairing...");
        pairingStatus = PAIR_REQUEST;
        autoPairing();
    } else {
        pairingStatus = PAIR_PAIRED;
        log(LOG_ERROR, "[Client] Loaded paired server from NVS:");
        printMAC(serverAddress, LOG_INFO);
         // Set the WiFi channel
        ESP_ERROR_CHECK(esp_wifi_set_channel(currentChannel, WIFI_SECOND_CHAN_NONE));

        initESP_NOW();

        // Add peer to ESP-NOW
        addPeer(serverAddress, currentChannel);
    }

    log(LOG_ERROR, "Client setup complete!");
}

void loop() {
checkPairingButton();
updatePairingLED();
checkSerialCommands();

if (pairingStatus != PAIR_PAIRED) {
    autoPairing();
    return; // Don't try to send data if not paired!
}
}
