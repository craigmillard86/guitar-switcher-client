#include "commandHandler.h"
#include "globals.h"
#include "espnow-pairing.h"
#include "utils.h"

void handleCommand(uint8_t commandType, uint8_t value) {
    switch (commandType) {
        case CHANGE_CHANNEL:
            log(LOG_ERROR, "[Client] Command: CHANGE_CHANNEL");
            currentChannel = value;
            break;
        default:
            log(LOG_WARN, "[Client] Unknown command received");
            break;
    }
}
