#include "utils.h"
#include <espnow-pairing.h>

void log(LogLevel level, const String& msg) {
    if (level <= currentLogLevel) {
        Serial.println(msg);
    }
}
void printMAC(const uint8_t *mac, LogLevel level) {
    char macStr[18];
    snprintf(macStr, sizeof(macStr), "%02X:%02X:%02X:%02X:%02X:%02X",
             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    log(level, String(macStr));
}

void blinkLED(uint8_t pin, int times, int delayMs) {
    for (int i = 0; i < times; i++) {
        digitalWrite(pin, HIGH);
        delay(delayMs);
        digitalWrite(pin, LOW);
        delay(delayMs);
    }
}

void checkSerialCommands() {
    if (Serial.available()) {
        String cmd = Serial.readStringUntil('\n');
        cmd.trim();
        if (cmd.equalsIgnoreCase("ota")) {
            serialOtaTrigger = true;
        } else if (cmd.equalsIgnoreCase("status")) {
            extern uint8_t clientMacAddress[6];
            printMAC(clientMacAddress, LOG_INFO);
        } else if (cmd.equalsIgnoreCase("reset")) {
            log(LOG_ERROR, "[Client] Restarting ESP...");
            delay(1000);
            ESP.restart();
        } else if (cmd.equalsIgnoreCase("pair")) {
            clearPairingNVS();
            pairingStatus = PAIR_REQUEST;
            log(LOG_ERROR, "[Client] Re-pairing requested!");
        } else if (cmd.startsWith("setlog")) {
            int level = cmd.substring(6).toInt();
            extern LogLevel currentLogLevel;
            currentLogLevel = (LogLevel)level;
            log(LOG_ERROR, "[Client] Log level set to: " + String(level));
        } else {
            log(LOG_WARN, "[Client] Unknown command: " + cmd);
        }
    }
}
