#pragma once
#include <Arduino.h>

void startOTA();
bool checkOtaTrigger();
